
import DestinationCard from "./DestinationCard";

// Updated destinations data with Indian locations
const destinations = [
  {
    id: "1",
    title: "Taj Mahal",
    location: "Agra, Uttar Pradesh",
    image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2148&q=80",
    price: 15000,
    rating: 4.8
  },
  {
    id: "2",
    title: "Goa Beaches",
    location: "Goa",
    image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
    price: 12500,
    rating: 4.6
  },
  {
    id: "3",
    title: "Varanasi Ghats",
    location: "Uttar Pradesh",
    image: "https://images.unsplash.com/photo-1561361058-c24ceccc6943?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
    price: 8999,
    rating: 4.7
  },
  {
    id: "4",
    title: "Himachal Mountains",
    location: "Himachal Pradesh",
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1140&q=80",
    price: 22999,
    rating: 4.9
  },
  {
    id: "5",
    title: "Kerala Backwaters",
    location: "Kerala",
    image: "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    price: 18999,
    rating: 4.5
  },
  {
    id: "6",
    title: "Jaipur Palace",
    location: "Rajasthan",
    image: "https://images.unsplash.com/photo-1477586957327-847a0f3f4fe3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
    price: 24999,
    rating: 4.9
  }
];

const FeaturedDestinations = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="travel-container">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold mb-3 text-gray-800">Featured Destinations in India</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our handpicked selection of stunning destinations across India, 
            perfect for your next adventure in the incredible land of diversity.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination) => (
            <DestinationCard 
              key={destination.id}
              id={destination.id}
              title={destination.title}
              location={destination.location}
              image={destination.image}
              price={destination.price}
              rating={destination.rating}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <button className="bg-travel-600 hover:bg-travel-700 text-white py-3 px-6 rounded-lg font-medium">
            View All Indian Destinations
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedDestinations;
