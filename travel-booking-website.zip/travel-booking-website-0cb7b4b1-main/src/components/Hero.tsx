
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Hero Background */}
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full bg-cover bg-center"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1524492412937-b28074a5d7da?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80')",
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
      </div>
      
      {/* Hero Content */}
      <div className="travel-container relative z-10 py-28 md:py-40">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Discover Incredible India
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8">
            Explore ancient temples, pristine beaches, majestic mountains, and vibrant cities across this diverse and beautiful country.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Button className="bg-travel-600 hover:bg-travel-700 text-white text-lg py-6 px-8">
              Explore India
            </Button>
            <Button variant="outline" className="text-white border-white hover:bg-white/10 text-lg py-6 px-8">
              View Special Offers
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
