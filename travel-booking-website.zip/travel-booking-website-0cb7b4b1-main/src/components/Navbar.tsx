
import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X, UserCircle, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm">
      <div className="travel-container py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Globe className="h-6 w-6 text-travel-600" />
            <Link to="/" className="text-2xl font-bold tracking-tight text-travel-700">
              IndiaTrails
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">
            <Link to="/" className="text-gray-600 hover:text-travel-600 font-medium">
              Home
            </Link>
            <Link to="/destinations" className="text-gray-600 hover:text-travel-600 font-medium">
              Destinations
            </Link>
            <Link to="/flights" className="text-gray-600 hover:text-travel-600 font-medium">
              Flights
            </Link>
            <Link to="/hotels" className="text-gray-600 hover:text-travel-600 font-medium">
              Hotels
            </Link>
            <Link to="/deals" className="text-gray-600 hover:text-travel-600 font-medium">
              Deals
            </Link>
          </div>
          
          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-travel-600">
              Sign In
            </Button>
            <Button className="bg-travel-600 hover:bg-travel-700 text-white">
              Sign Up
            </Button>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-500 hover:text-travel-600 focus:outline-none"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-2 animate-fade-in">
            <Link to="/" className="block py-2 text-gray-600 hover:text-travel-600 font-medium">
              Home
            </Link>
            <Link to="/destinations" className="block py-2 text-gray-600 hover:text-travel-600 font-medium">
              Destinations
            </Link>
            <Link to="/flights" className="block py-2 text-gray-600 hover:text-travel-600 font-medium">
              Flights
            </Link>
            <Link to="/hotels" className="block py-2 text-gray-600 hover:text-travel-600 font-medium">
              Hotels
            </Link>
            <Link to="/deals" className="block py-2 text-gray-600 hover:text-travel-600 font-medium">
              Deals
            </Link>
            <div className="pt-2 space-y-2">
              <Button variant="ghost" size="sm" className="w-full text-left text-gray-600">
                Sign In
              </Button>
              <Button className="w-full bg-travel-600 hover:bg-travel-700 text-white">
                Sign Up
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
