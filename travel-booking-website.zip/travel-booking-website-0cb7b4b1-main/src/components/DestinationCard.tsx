
import { Link } from "react-router-dom";
import { MapPin, Star, IndianRupee } from "lucide-react";

interface DestinationCardProps {
  id: string;
  title: string;
  location: string;
  image: string;
  price: number;
  rating: number;
}

const DestinationCard = ({ id, title, location, image, price, rating }: DestinationCardProps) => {
  return (
    <Link to={`/destination/${id}`} className="block">
      <div className="rounded-lg overflow-hidden shadow-md destination-card bg-white h-full">
        <div className="relative h-48">
          <img src={image} alt={title} className="w-full h-full object-cover" />
          <div className="absolute bottom-0 left-0 bg-travel-600 text-white px-3 py-1 rounded-tr-lg">
            <div className="flex items-center">
              <IndianRupee className="w-3 h-3 mr-1" />
              <span>{price.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
        <div className="p-4">
          <h3 className="font-semibold text-lg mb-2 text-gray-800">{title}</h3>
          <div className="flex items-center text-gray-500 mb-3">
            <MapPin className="w-4 h-4 mr-1" />
            <span className="text-sm">{location}</span>
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="ml-1 text-sm text-gray-700">{rating.toFixed(1)}</span>
            </div>
            <span className="text-xs text-gray-500">View Details</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default DestinationCard;
