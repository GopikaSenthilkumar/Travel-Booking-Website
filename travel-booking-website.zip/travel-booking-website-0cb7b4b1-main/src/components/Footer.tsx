import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Globe, Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-gray-300">
      <div className="travel-container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <Globe className="h-6 w-6 text-travel-400" />
              <span className="text-2xl font-bold text-white">IndiaTrails</span>
            </div>
            <p className="mb-6">
              Discover the beauty of India with IndiaTrails. We offer the best travel experiences and deals
              for your perfect Indian getaway.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-travel-400" aria-label="Facebook">
                <Facebook />
              </a>
              <a href="#" className="text-gray-400 hover:text-travel-400" aria-label="Twitter">
                <Twitter />
              </a>
              <a href="#" className="text-gray-400 hover:text-travel-400" aria-label="Instagram">
                <Instagram />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="hover:text-travel-400">Home</Link>
              </li>
              <li>
                <Link to="/destinations" className="hover:text-travel-400">Destinations</Link>
              </li>
              <li>
                <Link to="/flights" className="hover:text-travel-400">Flights</Link>
              </li>
              <li>
                <Link to="/hotels" className="hover:text-travel-400">Hotels</Link>
              </li>
              <li>
                <Link to="/deals" className="hover:text-travel-400">Special Deals</Link>
              </li>
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-6">Help</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/faq" className="hover:text-travel-400">FAQ</Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-travel-400">Terms of Service</Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-travel-400">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-travel-400">Contact Us</Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-3 text-travel-400" />
                <span>info@indiatrails.com</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-3 text-travel-400" />
                <span>xxxxxxx</span>
              </li>
            </ul>
            <div className="mt-6">
              <h4 className="text-white font-medium mb-3">Subscribe to our newsletter</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-4 py-2 w-full rounded-l-lg bg-gray-700 border-gray-600 text-white focus:outline-none focus:ring-1 focus:ring-travel-400"
                />
                <button className="bg-travel-600 hover:bg-travel-700 px-4 py-2 rounded-r-lg">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 text-sm text-center text-gray-400">
          <p>© {new Date().getFullYear()} IndiaTrails. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
