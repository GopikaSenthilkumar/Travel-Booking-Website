
import { useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Star, MapPin, Calendar, Clock, Users, Heart, Share2, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Sample destination data - in a real app, this would be fetched from an API
const destinations = [
  {
    id: "1",
    title: "Santorini Island",
    location: "Greece",
    image: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2148&q=80",
    price: 899,
    rating: 4.8,
    description: "Experience the breathtaking beauty of Santorini, with its iconic whitewashed buildings and stunning sunsets over the Aegean Sea. This package includes accommodations in a luxury hotel, daily breakfast, and a guided tour of the island's most beautiful spots.",
    duration: "7 days / 6 nights",
    groupSize: "Up to 10 people",
    highlights: [
      "Explore the picturesque villages of Oia and Fira",
      "Swim in crystal-clear waters at Red Beach",
      "Taste local wines from volcanic vineyards",
      "Watch the famous Santorini sunset",
      "Visit the ancient ruins of Akrotiri"
    ],
    itinerary: [
      {
        day: "Day 1",
        title: "Arrival and Welcome",
        description: "Arrive in Santorini, transfer to your hotel, and enjoy a welcome dinner with breathtaking views."
      },
      {
        day: "Day 2",
        title: "Oia Village Tour",
        description: "Explore the charming village of Oia with its blue-domed churches and winding streets."
      },
      {
        day: "Day 3",
        title: "Caldera Boat Tour",
        description: "Cruise around the caldera, visit the volcanic hot springs, and enjoy swimming in secluded bays."
      },
      {
        day: "Day 4",
        title: "Wine Tasting Experience",
        description: "Visit traditional wineries and taste unique wines produced from grapes grown in volcanic soil."
      },
      {
        day: "Day 5",
        title: "Ancient Akrotiri & Beaches",
        description: "Discover the prehistoric settlement of Akrotiri and relax at the famous Red Beach."
      },
      {
        day: "Day 6",
        title: "Hiking & Free Time",
        description: "Hike from Fira to Oia along the caldera edge, followed by free time to explore on your own."
      },
      {
        day: "Day 7",
        title: "Departure",
        description: "Enjoy a final breakfast before transferring to the airport for your departure."
      }
    ],
    reviews: [
      {
        user: "Maria L.",
        avatar: "https://randomuser.me/api/portraits/women/22.jpg",
        rating: 5,
        comment: "The most beautiful place I've ever visited! Our guide was knowledgeable and the hotel views were spectacular."
      },
      {
        user: "John D.",
        avatar: "https://randomuser.me/api/portraits/men/35.jpg",
        rating: 4,
        comment: "Great experience overall. The wine tasting tour was the highlight of our trip."
      },
      {
        user: "Elena K.",
        avatar: "https://randomuser.me/api/portraits/women/41.jpg",
        rating: 5,
        comment: "Perfect organization from start to finish. I'll definitely book another trip with VoyageQuest!"
      }
    ]
  }
  // More destinations would be added here in a real application
];

const DestinationDetail = () => {
  const { id } = useParams<{ id: string }>();
  const destination = destinations.find(dest => dest.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!destination) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Destination Not Found</h1>
            <p className="mb-6">We couldn't find the destination you're looking for.</p>
            <Link to="/" className="text-travel-600 hover:underline">Return to Home</Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <div className="relative h-96 bg-cover bg-center" style={{ backgroundImage: `url(${destination.image})` }}>
          <div className="absolute inset-0 bg-black bg-opacity-40" />
          <div className="travel-container relative z-10 h-full flex items-end pb-10">
            <div>
              <Link to="/" className="inline-flex items-center mb-4 text-white hover:text-travel-300">
                <ChevronLeft className="mr-1 h-5 w-5" />
                Back to all destinations
              </Link>
              <h1 className="text-4xl font-bold text-white mb-2">{destination.title}</h1>
              <div className="flex items-center text-white mb-2">
                <MapPin className="h-5 w-5 mr-1" />
                <span>{destination.location}</span>
              </div>
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-5 w-5 ${i < Math.floor(destination.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                  />
                ))}
                <span className="ml-2 text-white">{destination.rating} ({destination.reviews.length} reviews)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="travel-container py-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Left Content */}
            <div className="lg:col-span-2">
              {/* Tabs */}
              <Tabs defaultValue="overview">
                <TabsList className="w-full mb-6">
                  <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
                  <TabsTrigger value="itinerary" className="flex-1">Itinerary</TabsTrigger>
                  <TabsTrigger value="reviews" className="flex-1">Reviews</TabsTrigger>
                </TabsList>

                {/* Overview Tab */}
                <TabsContent value="overview" className="space-y-8">
                  {/* Description */}
                  <section>
                    <h2 className="text-2xl font-semibold mb-4">About This Trip</h2>
                    <p className="text-gray-600">{destination.description}</p>
                  </section>

                  {/* Highlights */}
                  <section>
                    <h2 className="text-2xl font-semibold mb-4">Trip Highlights</h2>
                    <ul className="space-y-3">
                      {destination.highlights.map((highlight, index) => (
                        <li key={index} className="flex items-start">
                          <div className="mr-3 mt-1 text-travel-600">•</div>
                          <span className="text-gray-600">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                </TabsContent>

                {/* Itinerary Tab */}
                <TabsContent value="itinerary" className="space-y-6">
                  <h2 className="text-2xl font-semibold mb-6">Trip Itinerary</h2>
                  {destination.itinerary.map((day, index) => (
                    <div key={index} className="border-l-2 border-travel-200 pl-5 pb-8 relative">
                      <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-travel-500"></div>
                      <h3 className="text-xl font-semibold text-travel-700">{day.day}</h3>
                      <h4 className="text-lg font-medium mb-2">{day.title}</h4>
                      <p className="text-gray-600">{day.description}</p>
                    </div>
                  ))}
                </TabsContent>

                {/* Reviews Tab */}
                <TabsContent value="reviews" className="space-y-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-semibold">Customer Reviews</h2>
                    <Button className="bg-travel-600 hover:bg-travel-700">Write a Review</Button>
                  </div>
                  
                  {destination.reviews.map((review, index) => (
                    <div key={index} className="border-b border-gray-200 pb-6 last:border-0">
                      <div className="flex items-start">
                        <img 
                          src={review.avatar} 
                          alt={review.user}
                          className="w-12 h-12 rounded-full mr-4" 
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold">{review.user}</h3>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                          </div>
                          <p className="text-gray-600">{review.comment}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>
            </div>

            {/* Right Sidebar - Booking Card */}
            <div>
              <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-6 sticky top-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-2xl font-semibold text-travel-700">
                    ${destination.price}
                    <span className="text-sm font-normal text-gray-500">/person</span>
                  </div>
                  <div className="flex space-x-2">
                    <button className="p-2 rounded-full border border-gray-200 hover:bg-gray-100">
                      <Heart className="h-5 w-5 text-gray-500" />
                    </button>
                    <button className="p-2 rounded-full border border-gray-200 hover:bg-gray-100">
                      <Share2 className="h-5 w-5 text-gray-500" />
                    </button>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-3 text-travel-600" />
                    <span>{destination.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-3 text-travel-600" />
                    <span>Available all year</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-3 text-travel-600" />
                    <span>{destination.groupSize}</span>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="font-medium mb-2">Select Date</h3>
                  <div className="border border-gray-200 rounded p-3 text-center cursor-pointer hover:border-travel-500">
                    <Calendar className="h-5 w-5 mx-auto mb-1 text-travel-600" />
                    <span className="text-sm">View Calendar</span>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="font-medium mb-2">Travelers</h3>
                  <div className="flex border border-gray-200 rounded overflow-hidden">
                    <button className="px-3 py-2 bg-gray-100 hover:bg-gray-200">-</button>
                    <div className="flex-1 text-center py-2">2</div>
                    <button className="px-3 py-2 bg-gray-100 hover:bg-gray-200">+</button>
                  </div>
                </div>

                <Button className="w-full bg-travel-600 hover:bg-travel-700 text-lg py-6">
                  Book Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default DestinationDetail;
