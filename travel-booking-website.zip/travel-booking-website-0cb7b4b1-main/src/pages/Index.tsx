
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SearchBar from "@/components/SearchBar";
import FeaturedDestinations from "@/components/FeaturedDestinations";
import Footer from "@/components/Footer";
import { Globe, Shield, CreditCard, Heart, Star } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        
        <div className="travel-container">
          <SearchBar />
        </div>
        
        <FeaturedDestinations />
        
        {/* Why Choose Us Section */}
        <section className="py-16 bg-white">
          <div className="travel-container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-3 text-gray-800">Why Choose IndiaTrails</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We're dedicated to making your travel dreams come true with exceptional service and unbeatable deals across India.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* Feature 1 */}
              <div className="text-center p-6 bg-gray-50 rounded-lg">
                <div className="mx-auto w-14 h-14 flex items-center justify-center rounded-full bg-travel-100 text-travel-600 mb-4">
                  <Globe className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">India Experts</h3>
                <p className="text-gray-600">
                  Our team consists of India travel specialists with deep knowledge of all regions and cultures.
                </p>
              </div>
              
              {/* Feature 2 */}
              <div className="text-center p-6 bg-gray-50 rounded-lg">
                <div className="mx-auto w-14 h-14 flex items-center justify-center rounded-full bg-travel-100 text-travel-600 mb-4">
                  <Shield className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Secure Booking</h3>
                <p className="text-gray-600">
                  Your payments and personal information are always protected with our secure platform.
                </p>
              </div>
              
              {/* Feature 3 */}
              <div className="text-center p-6 bg-gray-50 rounded-lg">
                <div className="mx-auto w-14 h-14 flex items-center justify-center rounded-full bg-travel-100 text-travel-600 mb-4">
                  <CreditCard className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Best Price Guarantee</h3>
                <p className="text-gray-600">
                  Find a lower price elsewhere? We'll match it and give you an additional 5% off.
                </p>
              </div>
              
              {/* Feature 4 */}
              <div className="text-center p-6 bg-gray-50 rounded-lg">
                <div className="mx-auto w-14 h-14 flex items-center justify-center rounded-full bg-travel-100 text-travel-600 mb-4">
                  <Heart className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">Personalized Experience</h3>
                <p className="text-gray-600">
                  Tailored recommendations based on your preferences for an authentic Indian adventure.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Testimonials Section */}
        <section className="py-16 bg-gray-50">
          <div className="travel-container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-3 text-gray-800">What Our Travelers Say</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Read about the experiences of travelers who have used IndiaTrails for their adventures.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Testimonial 1 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://randomuser.me/api/portraits/women/32.jpg" 
                    alt="Priya M."
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h4 className="font-semibold">Priya M.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "IndiaTrails made planning my Rajasthan tour so easy! The hotel recommendations 
                  were perfect and I saved so much on my flights."
                </p>
              </div>
              
              {/* Testimonial 2 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://randomuser.me/api/portraits/men/47.jpg" 
                    alt="Rahul J."
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h4 className="font-semibold">Rahul J.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "I've been using IndiaTrails for years and have never been disappointed. Their customer 
                  service is outstanding and they always find the best deals for Kerala tours."
                </p>
              </div>
              
              {/* Testimonial 3 */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://randomuser.me/api/portraits/women/68.jpg" 
                    alt="Anjali K."
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h4 className="font-semibold">Anjali K.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">
                  "The Himalayan package I booked through IndiaTrails exceeded all my expectations! Every 
                  detail was thought of and the value was incredible."
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
