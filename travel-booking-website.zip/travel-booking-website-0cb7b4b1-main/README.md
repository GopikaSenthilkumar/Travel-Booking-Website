
# India Trails - Travel Website Project

A beautiful travel website showcasing destinations across India.

## Project info

This is a React-based travel website project for exploring Indian destinations.

## How to run this project

Follow these steps to get started with the project:

```sh
# Step 1: Clone the repository
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory
cd india-trails

# Step 3: Install the necessary dependencies
npm i

# Step 4: Start the development server
npm run dev
```

## Technologies used

This project is built with:

- Vite
- TypeScript
- React
- Tailwind CSS
- shadcn/ui components

## Features

- Browse popular Indian destinations
- Search for specific locations
- Responsive design for all devices
- Beautiful UI with modern components

